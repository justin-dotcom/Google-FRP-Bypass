# Bypasser2019
!Notice:-you must put your device in fastboot mode okay 
Automated Shell Script To Bypass Google Verification in any Linux 
Made By hackerstech
Download google verification bypasser:https://github.com/hackerstech/Google-FRP-Bypass.git

usage :   
1)cd Desktop  
2)git clone https://github.com/hackerstech/Google-FRP-Bypass.git
3)cd Google-FRP-Bypass
4)chmod +x googlebypass.sh  
5)./googlebypass.sh

1) Bypass Google Verification 
2) Quit
Please enter your choice: 

Enjoy!!!!!!

Thanks for Using you're script 
# googleverificationbypass2019
